import re
import random
from commands import CommandRegistry, load_default_commands
from utils import get_current_time, get_current_date, calculate_expression

class JarvisChatbot:
    def __init__(self):
        # Crear y poblar el registro de comandos
        self.registry = CommandRegistry()
        load_default_commands(self.registry)
        
        # Respuestas básicas predefinidas (QA local)
        self.qa_responses = {
            r"\b(hola|buenos días|buenas tardes|buenas noches)\b": [
                "¡Hola! Soy Jarvis. ¿En qué puedo ayudarte hoy?",
                "Hola, un placer saludarte. ¿Qué comando deseas ejecutar?",
                "¡Hola! Estoy listo para asistirte en lo que necesites."
            ],
            r"\b(cómo estás|cómo te encuentras|qué tal)\b": [
                "Excelente, procesando datos de forma óptima. ¿Y tú?",
                "Estoy funcionando al cien por ciento de mi capacidad. Listo para servir.",
                "Muy bien, gracias por preguntar. Listo para ayudarte."
            ],
            r"\b(quién eres|tu nombre|quién te creó|creador)\b": [
                "Soy Jarvis Python Assistant, un asistente virtual universitario desarrollado en Python 3.12.",
                "Mi nombre es Jarvis. Fui creado como proyecto universitario para demostrar el poder de la automatización en Python."
            ],
            r"\b(qué puedes hacer|cuáles son tus funciones|funcionalidades)\b": [
                "Puedo darte la fecha y hora, abrir el Bloc de Notas, abrir la Calculadora, realizar búsquedas en Google y YouTube, hacer cálculos matemáticos básicos e interactuar por voz."
            ],
            r"\b(gracias|agradecido|perfecto|genial)\b": [
                "De nada. Es un placer ayudarte.",
                "A tu servicio siempre.",
                "¡Para eso estoy diseñado!"
            ]
        }

    def classify_intent_via_ai(self, query: str) -> str:
        """
        Consulta de forma ultrarrápida a Gemini para clasificar la intención del usuario
        y ejecutar programas locales de forma inteligente.
        """
        import os
        import requests
        
        api_key = os.getenv("GEMINI_API_KEY") or os.getenv("OPENROUTER_API_KEY") or os.getenv("GROQ_API_KEY")
        if not api_key or api_key == "tu_api_key_de_gemini_aqui":
            return "CONVERSAR"
            
        api_key = api_key.strip().strip('"').strip("'")
        
        models = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash"]
        for model in models:
            try:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
                headers = {"Content-Type": "application/json"}
                
                system_instruction = (
                    "Analiza la orden del usuario y clasifícala en una de las siguientes categorías. "
                    "Responde ÚNICAMENTE con la etiqueta en mayúsculas de la categoría, sin explicaciones ni puntuación:\n"
                    "- ABRIR_NOTEPAD (si quiere abrir notas, bloc de notas, escribir un bloc o notepad)\n"
                    "- ABRIR_CALCULADORA (si quiere abrir la calculadora, hacer cuentas o resolver operaciones matemáticas generales)\n"
                    "- ABRIR_GOOGLE (si quiere abrir google o buscar algo en internet)\n"
                    "- ABRIR_YOUTUBE (si quiere abrir youtube o reproducir videos)\n"
                    "- CERRAR_APP (si quiere apagar, salir, cerrar o despedirse)\n"
                    "- CONVERSAR (si es un saludo, una pregunta general, o cualquier otra cosa que no sea abrir los programas listados)"
                )
                
                payload = {
                    "systemInstruction": {
                        "parts": [{"text": system_instruction}]
                    },
                    "contents": [{
                        "parts": [{"text": query}]
                    }]
                }
                
                res = requests.post(url, json=payload, headers=headers, timeout=4)
                if res.status_code == 200:
                    label = res.json()["candidates"][0]["content"]["parts"][0]["text"].strip().upper()
                    label = label.replace('"', '').replace("'", "")
                    if label in ["ABRIR_NOTEPAD", "ABRIR_CALCULADORA", "ABRIR_GOOGLE", "ABRIR_YOUTUBE", "CERRAR_APP", "CONVERSAR"]:
                        return label
            except Exception:
                continue
        return "CONVERSAR"

    def process_input(self, user_input: str, app_instance=None) -> str:
        """
        Procesa la entrada del usuario (texto o voz transcrita).
        Determina si es un comando del sistema, una pregunta general,
        una operación matemática, o si cae en el fallback de no entender.
        """
        query = user_input.strip().lower()
        if not query:
            return "No he recibido ninguna entrada de texto."

        # 1. Si la entrada inicia con un slash (/), buscar y ejecutar el comando correspondiente de inmediato
        if query.startswith("/"):
            command = self.registry.find_command(query)
            if command:
                return command.execute(user_input, app_instance)

        # 2. Si el modo Gemini/IA está activo en la app, rutear directamente al modelo de lenguaje
        if app_instance and getattr(app_instance, "ai_mode_active", False):
            from commands import GeminiSearchCommand
            for cmd in self.registry.commands:
                if isinstance(cmd, GeminiSearchCommand):
                    return cmd.execute(user_input, app_instance)

        # 3. Comprobar si es un Comando del sistema estricto (coincidencia de palabras clave por defecto)
        command = self.registry.find_command(query)
        if command:
            return command.execute(user_input, app_instance)

        # 4. Modo Local - Enrutamiento 100% offline (sin llamadas a la API de Gemini para conservar cuota)
        query_clean = query.strip().lower()
        
        # ABRIR_NOTEPAD
        if any(w in query_clean for w in ["notepad", "bloc de notas", "escribir notas", "apuntar", "crear nota", "escribir algo", "bloc", "notas"]):
            cmd = self.registry.find_command("/notepad")
            if cmd: return cmd.execute(user_input, app_instance)
            
        # ABRIR_CALCULADORA
        if any(w in query_clean for w in ["calcula", "calcular", "cuenta", "operacion", "operación", "matematica", "matemática", "calculadora", "sumar", "restar"]):
            # Solo si no contiene números (para que las operaciones matemáticas se resuelvan abajo)
            if not any(char.isdigit() for char in query_clean):
                cmd = self.registry.find_command("/calculator")
                if cmd: return cmd.execute(user_input, app_instance)
                
        # ABRIR_GOOGLE
        if any(w in query_clean for w in ["google", "buscar en internet", "navegador", "abrir web", "buscar en la web"]):
            cmd = self.registry.find_command("/google")
            if cmd: return cmd.execute(user_input, app_instance)
            
        # ABRIR_YOUTUBE
        if any(w in query_clean for w in ["youtube", "video", "videos", "reproducir", "musica", "música"]):
            cmd = self.registry.find_command("/youtube")
            if cmd: return cmd.execute(user_input, app_instance)

        # 3. Consultar fecha y hora
        if any(kw in query for kw in ["hora es", "dime la hora", "qué hora tienes"]):
            return get_current_time()
        
        if any(kw in query for kw in ["fecha es", "dime la fecha", "qué día es hoy"]):
            return get_current_date()

        # 4. Operaciones matemáticas ("cuánto es X + Y", "calcula X * Y")
        if any(kw in query for kw in ["calcular", "calcula", "cuánto es", "suma", "resta", "multiplica", "divide"]):
            math_match = re.search(r'([\d+\-*/().\s]+)', query)
            if math_match:
                expr = math_match.group(1).strip()
                if len(expr) > 2 and any(op in expr for op in ["+", "-", "*", "/"]):
                    return calculate_expression(expr)

        # 5. Respuestas básicas predefinidas (QA)
        for pattern, responses in self.qa_responses.items():
            if re.search(pattern, query):
                return random.choice(responses)

        # 6. Fallback
        return "Lo siento, no tengo un comando o respuesta registrada para esa solicitud. Recuerda que puedes expandir mis funciones usando el sistema de plugins."
