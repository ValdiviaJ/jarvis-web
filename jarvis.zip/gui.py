import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import time
import math
import datetime
import requests
import cv2
import psutil
from PIL import Image, ImageTk
from chatbot import JarvisChatbot
from voice import VoiceEngine
from utils import log_conversation

# Colores del tema J.A.R.V.I.S (Iron Man Dashboard)
COLOR_BG = "#030712"         # Fondo general oscuro
COLOR_CARD = "#0B1329"       # Fondo de tarjetas
COLOR_CYAN = "#00F0FF"       # Cyan brillante para bordes y títulos
COLOR_BLUE = "#0072FF"       # Azul de selección/botones
COLOR_TEXT = "#E2E8F0"       # Texto claro
COLOR_GREEN = "#10B981"      # Verde de estado online
COLOR_ACCENT = "#EF4444"     # Rojo para detener
COLOR_DARK_TEXT = "#64748B"  # Gris oscuro para etiquetas secundarias

class CommandAutocomplete:
    def __init__(self, app_instance, entry_widget):
        self.app = app_instance
        self.entry = entry_widget
        self.popup = None
        self.commands = [
            "/search <pregunta> (Preguntar a la IA)",
            "/gemini <pregunta> (Preguntar a la IA)",
            "/notepad (Abrir Bloc de notas)",
            "/calculator (Abrir Calculadora)",
            "/google (Abrir Google)",
            "/youtube (Abrir YouTube)",
            "/exit (Cerrar asistente)"
        ]

        # Vincular eventos de teclado y foco
        self.entry.bind("<KeyRelease>", self.on_key_release)
        self.app.root.bind("<Configure>", lambda e: self.hide())
        self.entry.bind("<FocusOut>", self.on_focus_out)

    def on_focus_out(self, event):
        self.app.root.after(200, self.hide)

    def on_key_release(self, event):
        text = self.entry.get()
        if text.startswith("/"):
            query = text.lower()
            matching_commands = [c for c in self.commands if c.lower().startswith(query)]
            
            if matching_commands:
                self.show_popup(matching_commands)
            else:
                self.hide()
        else:
            self.hide()

    def show_popup(self, command_list):
        if self.popup:
            self.listbox.delete(0, tk.END)
            for cmd in command_list:
                self.listbox.insert(tk.END, cmd)
            h = min(len(command_list) * 22 + 5, 160)
            self.popup.geometry(f"{self.entry.winfo_width()}x{h}")
            return

        self.popup = tk.Toplevel(self.app.root)
        self.popup.overrideredirect(True)
        self.popup.configure(bg=COLOR_CARD)
        
        # Calcular posición arriba del campo de texto
        x = self.entry.winfo_rootx()
        h = min(len(command_list) * 22 + 5, 160)
        y = self.entry.winfo_rooty() - h - 5
        self.popup.geometry(f"{self.entry.winfo_width()}x{h}+{x}+{y}")
        
        self.listbox = tk.Listbox(
            self.popup, 
            bg=COLOR_CARD, 
            fg=COLOR_CYAN, 
            selectbackground=COLOR_BLUE, 
            selectforeground=COLOR_TEXT,
            font=("Consolas", 10),
            bd=1,
            highlightbackground=COLOR_BLUE,
            highlightthickness=1,
            relief=tk.FLAT
        )
        self.listbox.pack(fill=tk.BOTH, expand=True)
        
        for cmd in command_list:
            self.listbox.insert(tk.END, cmd)
            
        self.listbox.bind("<Double-Button-1>", self.on_select)
        self.listbox.bind("<Return>", self.on_select)
        self.listbox.bind("<Escape>", lambda e: self.hide())
        self.entry.bind("<Down>", lambda e: self.focus_listbox())

    def focus_listbox(self):
        if self.popup:
            self.listbox.focus_set()
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(0)

    def hide(self):
        if self.popup:
            try:
                self.popup.destroy()
            except Exception:
                pass
            self.popup = None

    def on_select(self, event=None):
        try:
            selection = self.listbox.curselection()
            if selection:
                selected_text = self.listbox.get(selection[0])
                cmd_name = selected_text.split(" ")[0]
                
                self.entry.delete(0, tk.END)
                self.entry.insert(0, cmd_name + " ")
                self.entry.focus_set()
                self.entry.icursor(tk.END)
        except Exception:
            pass
        self.hide()


class JarvisApp:
    def __init__(self, root):
        self.root = root
        self.root.title("J.A.R.V.I.S Dashboard")
        self.root.geometry("1280x800")
        self.root.configure(bg=COLOR_BG)
        
        # Variables de estado
        self.is_listening = False
        self.is_speaking = False
        self.angle = 0
        self.camera_active = False
        self.camera_index = 0
        self.cap = None
        self.commands_count = 0
        self.start_time = time.time()
        self.ai_mode_active = False
        self.hud_status = "STANDBY"
        self.finger_counter_frames = 0
        self.last_finger_count = -1
        self.last_triggered_count = -1
        self.last_triggered_time = 0
        
        # Inicializar motores
        self.chatbot = JarvisChatbot()
        self.voice_engine = VoiceEngine()
        
        # Estilo de elementos de interfaz
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure('.', background=COLOR_BG, foreground=COLOR_TEXT)
        self.style.configure('TFrame', background=COLOR_BG)
        
        self.build_dashboard()
        self.animate_hud()
        self.update_stats()
        self.update_clock()
        self.fetch_weather_async()
        
        # Saludo inicial
        self.welcome_greeting()

    def build_dashboard(self):
        # ----------------------------------------------------
        # TOP BAR
        # ----------------------------------------------------
        self.top_bar = tk.Frame(self.root, bg=COLOR_BG, height=60, bd=1, relief=tk.FLAT)
        self.top_bar.pack(side=tk.TOP, fill=tk.X, padx=15, pady=5)
        self.top_bar.pack_propagate(False)
        
        self.logo_frame = tk.Frame(self.top_bar, bg=COLOR_BG)
        self.logo_frame.pack(side=tk.LEFT)
        
        self.logo_label = tk.Label(self.logo_frame, text="J.A.R.V.I.S", font=("Courier New", 20, "bold"), fg=COLOR_CYAN, bg=COLOR_BG)
        self.logo_label.pack(side=tk.LEFT, padx=(5, 10))
        
        self.pill_label = tk.Label(self.logo_frame, text="● Online", font=("Segoe UI", 9, "bold"), fg=COLOR_GREEN, bg="#0E211B", padx=8, pady=2)
        self.pill_label.pack(side=tk.LEFT)
        
        # Reloj central
        self.clock_label = tk.Label(self.top_bar, text="--:--:-- | -- -- ----", font=("Segoe UI Semibold", 12), fg=COLOR_TEXT, bg=COLOR_BG)
        self.clock_label.pack(side=tk.LEFT, expand=True)
        
        # Clima rápido (Top-right)
        self.weather_top_label = tk.Label(self.top_bar, text="⛅ Cargando clima...", font=("Segoe UI", 10), fg=COLOR_TEXT, bg=COLOR_BG)
        self.weather_top_label.pack(side=tk.RIGHT, padx=15)
        
        # Divider line
        divider = tk.Frame(self.root, height=1, bg="#1E293B")
        divider.pack(fill=tk.X)

        # ----------------------------------------------------
        # MAIN LAYOUT FRAME
        # ----------------------------------------------------
        self.layout_frame = tk.Frame(self.root, bg=COLOR_BG)
        self.layout_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=10)

        # LEFT COLUMN (System Stats & Weather & Camera & Uptime)
        self.left_col = tk.Frame(self.layout_frame, bg=COLOR_BG, width=300)
        self.left_col.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 10))
        self.left_col.pack_propagate(False)

        # CENTER COLUMN (HUD Visualizer)
        self.center_col = tk.Frame(self.layout_frame, bg=COLOR_BG)
        self.center_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10)

        # RIGHT COLUMN (Chat Conversation)
        self.right_col = tk.Frame(self.layout_frame, bg=COLOR_BG, width=380)
        self.right_col.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(10, 0))
        self.right_col.pack_propagate(False)

        # ----------------------------------------------------
        # LEFT COLUMN CARDS
        # ----------------------------------------------------
        # Card 1: System Stats
        self.card_stats = self.create_card(self.left_col, "System Stats")
        self.cpu_label = tk.Label(self.card_stats, text="CPU Usage", font=("Segoe UI", 9), fg=COLOR_TEXT, bg=COLOR_CARD)
        self.cpu_label.pack(anchor=tk.W, padx=10, pady=(5, 0))
        self.cpu_bar = ttk.Progressbar(self.card_stats, length=240)
        self.cpu_bar.pack(fill=tk.X, padx=10, pady=(2, 5))
        
        self.ram_label = tk.Label(self.card_stats, text="RAM Usage", font=("Segoe UI", 9), fg=COLOR_TEXT, bg=COLOR_CARD)
        self.ram_label.pack(anchor=tk.W, padx=10)
        self.ram_bar = ttk.Progressbar(self.card_stats, length=240)
        self.ram_bar.pack(fill=tk.X, padx=10, pady=(2, 10))

        # Card 2: Weather info
        self.card_weather = self.create_card(self.left_col, "Weather")
        self.temp_val_label = tk.Label(self.card_weather, text="--°C", font=("Segoe UI Semibold", 18), fg=COLOR_CYAN, bg=COLOR_CARD)
        self.temp_val_label.pack(anchor=tk.W, padx=10, pady=(5, 0))
        self.weather_loc_label = tk.Label(self.card_weather, text="Cargando localización...", font=("Segoe UI", 9), fg=COLOR_DARK_TEXT, bg=COLOR_CARD)
        self.weather_loc_label.pack(anchor=tk.W, padx=10)
        
        # Grid para detalles del clima
        self.weather_details = tk.Frame(self.card_weather, bg=COLOR_CARD)
        self.weather_details.pack(fill=tk.X, padx=10, pady=(5, 10))
        
        self.humidity_lbl = tk.Label(self.weather_details, text="Humedad:\n--", font=("Segoe UI", 8), fg=COLOR_TEXT, bg=COLOR_CARD, justify=tk.LEFT)
        self.humidity_lbl.grid(row=0, column=0, sticky=tk.W, padx=(0, 20))
        self.wind_lbl = tk.Label(self.weather_details, text="Viento:\n--", font=("Segoe UI", 8), fg=COLOR_TEXT, bg=COLOR_CARD, justify=tk.LEFT)
        self.wind_lbl.grid(row=0, column=1, sticky=tk.W, padx=(0, 20))
        self.feels_lbl = tk.Label(self.weather_details, text="Sensación:\n--", font=("Segoe UI", 8), fg=COLOR_TEXT, bg=COLOR_CARD, justify=tk.LEFT)
        self.feels_lbl.grid(row=0, column=2, sticky=tk.W)

        # Card 3: Camera
        self.card_camera = self.create_card(self.left_col, "Camera")
        self.camera_frame = tk.Frame(self.card_camera, bg=COLOR_BG, height=150)
        self.camera_frame.pack(fill=tk.X, padx=10, pady=5)
        self.camera_frame.pack_propagate(False)
        
        self.camera_label = tk.Label(
            self.camera_frame, 
            text="Camera Off\n(Click to turn on / switch)", 
            font=("Segoe UI Semibold", 9), 
            fg=COLOR_DARK_TEXT, 
            bg=COLOR_BG,
            cursor="hand2"
        )
        self.camera_label.pack(fill=tk.BOTH, expand=True)
        self.camera_label.bind("<Button-1>", self.on_camera_click)

        # Card 4: System Uptime
        self.card_uptime = self.create_card(self.left_col, "System Uptime")
        self.uptime_label = tk.Label(self.card_uptime, text="Uptime: 00:00:00", font=("Segoe UI Semibold", 9), fg=COLOR_TEXT, bg=COLOR_CARD)
        self.uptime_label.pack(anchor=tk.W, padx=10, pady=(5, 2))
        
        self.stats_summary_label = tk.Label(self.card_uptime, text="Sesiones: 1   |   Comandos: 0", font=("Segoe UI", 8), fg=COLOR_DARK_TEXT, bg=COLOR_CARD)
        self.stats_summary_label.pack(anchor=tk.W, padx=10, pady=(0, 10))

        # ----------------------------------------------------
        # CENTER COLUMN HUD VISUALIZER
        # ----------------------------------------------------
        # Canvas del visualizador Arc Reactor
        self.canvas = tk.Canvas(self.center_col, width=320, height=320, bg=COLOR_BG, highlightthickness=0)
        self.canvas.pack(pady=(60, 20))
        
        self.center_title = tk.Label(self.center_col, text="J.A.R.V.I.S", font=("Courier New", 24, "bold"), fg=COLOR_TEXT, bg=COLOR_BG)
        self.center_title.pack()
        
        self.status_badge = tk.Label(
            self.center_col, 
            text="● STANDBY", 
            font=("Segoe UI", 9, "bold"), 
            fg=COLOR_CYAN, 
            bg="#0B1329", 
            padx=12, 
            pady=4
        )
        self.status_badge.pack(pady=10)

        # Botones de control inferiores
        self.bottom_control_frame = tk.Frame(self.center_col, bg=COLOR_BG)
        self.bottom_control_frame.pack(side=tk.BOTTOM, pady=30)

        self.btn_cam = tk.Button(
            self.bottom_control_frame, 
            text="📷 CAM", 
            font=("Courier New", 10, "bold"), 
            bg=COLOR_CARD, 
            fg=COLOR_TEXT, 
            activebackground=COLOR_CYAN,
            activeforeground=COLOR_BG,
            bd=1,
            highlightthickness=0,
            padx=15, 
            pady=8,
            cursor="hand2",
            command=self.toggle_camera
        )
        self.btn_cam.pack(side=tk.LEFT, padx=10)

        self.btn_mic = tk.Button(
            self.bottom_control_frame, 
            text="🎙️ LISTEN", 
            font=("Courier New", 10, "bold"), 
            bg=COLOR_BLUE, 
            fg=COLOR_TEXT, 
            activebackground=COLOR_CYAN,
            activeforeground=COLOR_BG,
            bd=0, 
            padx=20, 
            pady=8,
            cursor="hand2",
            command=self.listen_voice_message
        )
        self.btn_mic.pack(side=tk.LEFT, padx=10)

        self.btn_kb = tk.Button(
            self.bottom_control_frame, 
            text="⌨️ FOCUS", 
            font=("Courier New", 10, "bold"), 
            bg=COLOR_CARD, 
            fg=COLOR_TEXT, 
            activebackground=COLOR_CYAN,
            activeforeground=COLOR_BG,
            bd=1,
            highlightthickness=0,
            padx=15, 
            pady=8,
            cursor="hand2",
            command=lambda: self.entry_field.focus_set()
        )
        self.btn_kb.pack(side=tk.LEFT, padx=10)

        # ----------------------------------------------------
        # RIGHT COLUMN CARDS (Conversation)
        # ----------------------------------------------------
        # Header de Conversación
        self.convo_header = tk.Frame(self.right_col, bg=COLOR_BG)
        self.convo_header.pack(fill=tk.X, pady=(0, 10))
        
        self.convo_title = tk.Label(self.convo_header, text="Conversation", font=("Segoe UI Semibold", 12), fg=COLOR_TEXT, bg=COLOR_BG)
        self.convo_title.pack(side=tk.LEFT)
        
        self.clear_btn = tk.Button(
            self.convo_header, 
            text="Clear", 
            font=("Segoe UI", 8, "bold"), 
            bg="#1E293B", 
            fg=COLOR_TEXT,
            bd=0, 
            padx=10, 
            cursor="hand2",
            command=self.clear_chat
        )
        self.clear_btn.pack(side=tk.RIGHT)

        # Entrada inferior
        self.input_frame = tk.Frame(self.right_col, bg=COLOR_BG, height=60)
        self.input_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=(10, 0))
        self.input_frame.pack_propagate(False)

        # Botón selector de Modo (Local vs IA)
        self.mode_btn = tk.Button(
            self.input_frame,
            text="🤖 LOCAL",
            font=("Courier New", 9, "bold"),
            bg=COLOR_CARD,
            fg=COLOR_GREEN,
            activebackground=COLOR_CARD,
            activeforeground=COLOR_GREEN,
            bd=1,
            highlightbackground="#1E293B",
            highlightthickness=0,
            padx=10,
            cursor="hand2",
            command=self.toggle_ai_mode
        )
        self.mode_btn.pack(side=tk.LEFT, fill=tk.Y, pady=10, padx=(0, 5))

        self.entry_field = tk.Entry(
            self.input_frame, 
            font=("Segoe UI", 11), 
            bg=COLOR_CARD, 
            fg=COLOR_TEXT, 
            insertbackground=COLOR_CYAN,
            bd=0,
            highlightthickness=1,
            highlightbackground="#1E293B",
            highlightcolor=COLOR_CYAN
        )
        self.entry_field.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10), pady=10)
        self.entry_field.bind("<Return>", lambda e: self.send_text_message())
        
        self.autocomplete = CommandAutocomplete(self, self.entry_field)

        self.send_btn = tk.Button(
            self.input_frame, 
            text="✈", 
            font=("Segoe UI", 12), 
            bg=COLOR_BLUE, 
            fg=COLOR_TEXT, 
            activebackground=COLOR_CYAN,
            activeforeground=COLOR_BG,
            bd=0, 
            width=4,
            cursor="hand2",
            command=self.send_text_message
        )
        self.send_btn.pack(side=tk.RIGHT, fill=tk.Y, pady=10)

        # Historial de Chat (Centro)
        self.chat_history = scrolledtext.ScrolledText(
            self.right_col, 
            wrap=tk.WORD, 
            font=("Segoe UI", 10), 
            bg=COLOR_CARD, 
            fg=COLOR_TEXT,
            insertbackground=COLOR_CYAN,
            bd=0,
            highlightthickness=1,
            highlightbackground="#1E293B",
            highlightcolor=COLOR_CYAN
        )
        self.chat_history.pack(fill=tk.BOTH, expand=True)
        self.chat_history.configure(state='disabled')
        
        # Tags de colores en chat
        self.chat_history.tag_config("jarvis", foreground=COLOR_CYAN, font=("Segoe UI", 10, "bold"))
        self.chat_history.tag_config("user", foreground=COLOR_GREEN, font=("Segoe UI", 10, "bold"))
        self.chat_history.tag_config("system", foreground=COLOR_DARK_TEXT, font=("Segoe UI", 9, "italic"))

    def create_card(self, parent, title):
        """Helper para construir tarjetas con bordes cyan del HUD."""
        card = tk.Frame(parent, bg=COLOR_CARD, bd=1, relief=tk.FLAT, highlightbackground="#1E293B", highlightthickness=1)
        card.pack(fill=tk.X, pady=(0, 15))
        
        # Título de la tarjeta
        header = tk.Label(card, text=title.upper(), font=("Segoe UI Semibold", 8, "bold"), fg=COLOR_CYAN, bg=COLOR_CARD, anchor=tk.W)
        header.pack(fill=tk.X, padx=10, pady=(8, 2))
        
        return card

    def update_clock(self):
        """Actualiza el reloj y fecha del top bar."""
        now = datetime.datetime.now()
        time_str = now.strftime("%I:%M:%S %p")
        date_str = now.strftime("%B %d, %Y")
        self.clock_label.config(text=f"{time_str}  |  {date_str}")
        
        # Uptime
        uptime_seconds = int(time.time() - self.start_time)
        hours = uptime_seconds // 3600
        minutes = (uptime_seconds % 3600) // 60
        seconds = uptime_seconds % 60
        self.uptime_label.config(text=f"Uptime: {hours:02d}:{minutes:02d}:{seconds:02d}")
        
        self.root.after(1000, self.update_clock)

    def update_stats(self):
        """Actualiza el consumo de CPU y RAM de forma local y asincrónica."""
        try:
            cpu = psutil.cpu_percent()
            ram = psutil.virtual_memory().percent
            
            self.cpu_bar['value'] = cpu
            self.cpu_label.config(text=f"CPU Usage ({int(cpu)}%)")
            
            self.ram_bar['value'] = ram
            self.ram_label.config(text=f"RAM Usage ({int(ram)}%)")
            
            # System Load summary
            self.stats_summary_label.config(text=f"Sesiones: 1   |   Comandos: {self.commands_count}")
        except Exception:
            pass
        self.root.after(2000, self.update_stats)

    def fetch_weather_async(self):
        """Realiza la petición de clima de forma asincrónica."""
        def fetch():
            try:
                # Consultar wttr.in en formato JSON
                url = "https://wttr.in?format=j1"
                res = requests.get(url, timeout=5)
                if res.status_code == 200:
                    data = res.json()
                    curr = data.get("current_condition", [{}])[0]
                    area = data.get("nearest_area", [{}])[0]
                    
                    temp = curr.get("temp_C", "--")
                    humidity = curr.get("humidity", "--")
                    wind = curr.get("windspeedKmph", "--")
                    feels = curr.get("FeelsLikeC", "--")
                    desc = curr.get("lang_es", [{}])[0].get("value", "Clima")
                    
                    city = area.get("areaName", [{}])[0].get("value", "Local")
                    country = area.get("country", [{}])[0].get("value", "")
                    
                    # Actualizar UI en hilo principal
                    self.root.after(0, lambda: self.update_weather_ui(temp, city, country, humidity, wind, feels, desc))
            except Exception:
                # Si falla o está offline, usar valores estáticos realistas de fallback
                self.root.after(0, self.set_mock_weather)
                
        threading.Thread(target=fetch, daemon=True).start()

    def update_weather_ui(self, temp, city, country, humidity, wind, feels, desc):
        self.temp_val_label.config(text=f"{temp}°C")
        self.weather_loc_label.config(text=f"{city}, {country}\n{desc.lower()}")
        self.humidity_lbl.config(text=f"Humedad:\n{humidity}%")
        self.wind_lbl.config(text=f"Viento:\n{wind} km/h")
        self.feels_lbl.config(text=f"Sensación:\n{feels}°C")
        self.weather_top_label.config(text=f"⛅ {temp}°C {city}")

    def set_mock_weather(self):
        # Fallback offline
        self.temp_val_label.config(text="24°C")
        self.weather_loc_label.config(text="Localización Offline\ndespejado")
        self.humidity_lbl.config(text="Humedad:\n65%")
        self.wind_lbl.config(text="Viento:\n12 km/h")
        self.feels_lbl.config(text="Sensación:\n25°C")
        self.weather_top_label.config(text="⛅ 24°C Offline")

    def animate_hud(self):
        """
        Dibuja y anima el reactor arc de J.A.R.V.I.S en el canvas.
        Implementa un diseño holográfico de ciencia ficción con ondas fluidas,
        partículas orbitales, arcos segmentados en contrarrotación, mira táctica
        y núcleo hiperreactivo.
        """
        self.canvas.delete("all")
        cx, cy = 160, 160
        t = time.time()
        
        # Determinar el estado para los efectos dinámicos
        hud_lower = self.hud_status.lower()
        if "escuchando" in hud_lower or "ruido" in hud_lower or "procesando" in hud_lower:
            # Modo escucha: Muy reactivo, eléctrico, rápido (verde)
            color = COLOR_GREEN
            bg_color = "#0F211B"
            base_pulse = 1.0 + 0.15 * math.sin(t * 22)
            wave_amp = 25 + 18 * math.sin(t * 35)
            speed_multiplier = 2.5
        elif "hablando" in hud_lower:
            # Modo hablando: Ondas sinoidales fluidas y amplias (azul)
            color = COLOR_BLUE
            bg_color = "#0C1524"
            base_pulse = 1.0 + 0.08 * math.sin(t * 14)
            wave_amp = 18 + 12 * math.sin(t * 18)
            speed_multiplier = 1.5
        elif "error" in hud_lower or "no se" in hud_lower or "agotado" in hud_lower:
            # Modo error/alarma (rojo)
            color = COLOR_ACCENT
            bg_color = "#2D1515"
            base_pulse = 1.0 + 0.06 * math.sin(t * 10)
            wave_amp = 8 + 4 * math.sin(t * 12)
            speed_multiplier = 0.8
        else:
            # Modo Standby: Respiración lenta y elegante (cyan)
            color = COLOR_CYAN
            bg_color = "#0B1329"
            base_pulse = 1.0 + 0.04 * math.sin(t * 3.5)
            wave_amp = 7 + 4 * math.sin(t * 6)
            speed_multiplier = 1.0

        # Velocidades de rotación ajustadas con el multiplicador
        rot_outer = t * 60 * speed_multiplier
        rot_inner = -t * 90 * speed_multiplier
        rot_mid = t * 45 * speed_multiplier

        # --- CAPA 0: MIRA DE DIANA TÁCTICA (Crosshairs / Ticks) ---
        # Líneas de referencia del HUD militar/holograma en los bordes externos
        r_cross = 135
        for ang in [0, 90, 180, 270]:
            rad = math.radians(ang)
            # Líneas de cruz
            x1 = cx + (r_cross - 8) * math.cos(rad)
            y1 = cy + (r_cross - 8) * math.sin(rad)
            x2 = cx + (r_cross + 8) * math.cos(rad)
            y2 = cy + (r_cross + 8) * math.sin(rad)
            self.canvas.create_line(x1, y1, x2, y2, fill="#1E293B", width=1)
            
            # Pequeñas marcas angulares externas
            rad_offset = math.radians(ang + 45)
            tx = cx + r_cross * math.cos(rad_offset)
            ty = cy + r_cross * math.sin(rad_offset)
            self.canvas.create_oval(tx-2, ty-2, tx+2, ty+2, fill="#0e7490", outline="")

        # --- CAPA 1: ANILLO HOLOGRÁFICO EXTERNO Y ARCOS SEGMENTADOS ---
        r_outer = 118 * base_pulse
        # Círculo fino de fondo
        self.canvas.create_oval(cx-r_outer, cy-r_outer, cx+r_outer, cy+r_outer, outline="#083344", width=1)
        
        # Arcos exteriores en contrarrotación
        num_arcs = 3
        arc_len = 70
        for i in range(num_arcs):
            start_angle = (rot_outer + (i * 360 / num_arcs)) % 360
            self.canvas.create_arc(
                cx-r_outer-5, cy-r_outer-5, cx+r_outer+5, cy+r_outer+5,
                start=start_angle, extent=arc_len,
                style=tk.ARC, outline=color, width=2
            )
            
            # Anillo concéntrico discontinuo intermedio
            start_angle_inner = (-rot_outer * 0.7 + (i * 360 / num_arcs) + 60) % 360
            self.canvas.create_arc(
                cx-r_outer+10, cy-r_outer+10, cx+r_outer-10, cy+r_outer-10,
                start=start_angle_inner, extent=30,
                style=tk.ARC, outline="#0e7490", width=1
            )

        # --- CAPA 2: PARTÍCULAS ORBITALES (Glow particles) ---
        # Pequeños nodos que orbitan alrededor del núcleo de energía
        num_particles = 4
        for i in range(num_particles):
            p_angle = (rot_mid * 1.5 + (i * 360 / num_particles)) % 360
            p_rad = math.radians(p_angle)
            # Órbita ondulante
            p_dist = (95 + 8 * math.sin(t * 8 + i)) * base_pulse
            px = cx + p_dist * math.cos(p_rad)
            py = cy + p_dist * math.sin(p_rad)
            
            # Partícula sólida
            self.canvas.create_oval(px-4, py-4, px+4, py+4, fill=color, outline="#FFFFFF", width=1)
            # Destello/Glow exterior de la partícula
            self.canvas.create_oval(px-8, py-8, px+8, py+8, outline=color, width=1)

        # --- CAPA 3: ECUALIZADOR FLUIDO DE FRECUENCIA RADIAL ---
        # En vez de barras aleatorias, forman una onda sinoidal fluida que fluye alrededor
        r_mid = 72 * base_pulse
        num_bars = 32
        for i in range(num_bars):
            angle_deg = (rot_inner + (i * 360 / num_bars)) % 360
            angle_rad = math.radians(angle_deg)
            
            # Onda que se propaga por índice (i) y tiempo (t) para dar efecto fluido de flujo de datos
            wave_func = math.sin(t * 12 - i * 0.4) * math.cos(t * 4 + i * 0.1)
            bar_height = wave_amp * (1.0 + 0.9 * wave_func)
            
            x1 = cx + r_mid * math.cos(angle_rad)
            y1 = cy + r_mid * math.sin(angle_rad)
            x2 = cx + (r_mid + bar_height) * math.cos(angle_rad)
            y2 = cy + (r_mid + bar_height) * math.sin(angle_rad)
            
            # Color con gradiente visual (el extremo de la barra puede ser blanco/cyan brillante)
            self.canvas.create_line(x1, y1, x2, y2, fill=color, width=2)
            if bar_height > 12:
                # Pequeño punto brillante en el extremo de la onda alta
                self.canvas.create_oval(x2-1.5, y2-1.5, x2+1.5, y2+1.5, fill="#FFFFFF", outline="")

        # --- CAPA 4: PENTÁGONO/HEXÁGONO ROTATIVO Y ANILLO INTERNO ---
        r_inner = 48 * base_pulse
        self.canvas.create_oval(cx-r_inner, cy-r_inner, cx+r_inner, cy+r_inner, outline=color, width=2)
        
        # Geometría del reactor: un hexágono rotativo
        num_sides = 6
        hex_points = []
        for i in range(num_sides):
            ang_rad = math.radians(rot_outer * 1.2 + (i * 360 / num_sides))
            tx = cx + (r_inner - 6) * math.cos(ang_rad)
            ty = cy + (r_inner - 6) * math.sin(ang_rad)
            hex_points.extend([tx, ty])
            # Líneas radiales del núcleo al hexágono para conectividad futurista
            self.canvas.create_line(cx, cy, tx, ty, fill="#083344", width=1)
            
        self.canvas.create_polygon(hex_points, outline=color, fill="", width=1.5)

        # --- CAPA 5: NÚCLEO MULTICAPA HIPERREACTIVO ---
        r_core = 16 * base_pulse
        # Aura exterior del núcleo
        self.canvas.create_oval(cx-r_core-8, cy-r_core-8, cx+r_core+8, cy+r_core+8, outline=color, width=1, dash=(2, 4))
        # Anillo de contención
        self.canvas.create_oval(cx-r_core-3, cy-r_core-3, cx+r_core+3, cy+r_core+3, outline="#FFFFFF", width=1)
        # Núcleo central sólido con pulsación
        self.canvas.create_oval(cx-r_core, cy-r_core, cx+r_core, cy+r_core, fill=color, outline="#FFFFFF", width=2)
        
        # Efecto de destello cruzado en el centro del núcleo
        self.canvas.create_line(cx-6, cy, cx+6, cy, fill="#FFFFFF", width=1.5)
        self.canvas.create_line(cx, cy-6, cx, cy+6, fill="#FFFFFF", width=1.5)

        # Actualizar estado de texto en el badge
        self.status_badge.config(text=f"● {self.hud_status.upper()}", fg=color, bg=bg_color)
        
        # Siguiente frame
        self.root.after(30, self.animate_hud)


    def append_chat(self, sender: str, text: str):
        self.chat_history.configure(state='normal')
        if sender == "JARVIS":
            self.chat_history.insert(tk.END, "JARVIS: ", "jarvis")
            self.chat_history.insert(tk.END, f"{text}\n\n")
            log_conversation("JARVIS", text)
        elif sender == "USUARIO":
            self.chat_history.insert(tk.END, "USUARIO: ", "user")
            self.chat_history.insert(tk.END, f"{text}\n\n")
            log_conversation("USUARIO", text)
        else:
            self.chat_history.insert(tk.END, f"[Sistema] {text}\n\n", "system")
            
        self.chat_history.configure(state='disabled')
        self.chat_history.see(tk.END)

    def welcome_greeting(self):
        def greet():
            time.sleep(0.5)
            greeting = "Sistemas centrales cargados. Hola Stark, soy Jarvis. Listo para recibir tus comandos."
            self.append_chat("JARVIS", greeting)
            
            # Cambiar estado a hablando durante TTS
            self.is_speaking = True
            self.voice_engine.speak(greeting)
            # Esperar aproximado para volver a standby
            time.sleep(4)
            self.is_speaking = False

        threading.Thread(target=greet, daemon=True).start()

    def send_text_message(self):
        user_text = self.entry_field.get().strip()
        if not user_text:
            return
            
        self.entry_field.delete(0, tk.END)
        self.append_chat("USUARIO", user_text)
        self.commands_count += 1
        
        def run_process():
            self.is_speaking = True
            
            response = self.chatbot.process_input(user_text, self)
            self.append_chat("JARVIS", response)
            self.voice_engine.speak(response)
            
            # Volver a standby tras hablar
            time.sleep(max(len(response) * 0.08, 2))
            self.is_speaking = False

        threading.Thread(target=run_process, daemon=True).start()

    def listen_voice_message(self):
        if not self.voice_engine.stt_enabled:
            err = self.voice_engine.stt_error
            detail = ""
            if "no default input device" in err.lower() or "device" in err.lower():
                detail = "\n(No se encontró ningún micrófono conectado o habilitado en la configuración de sonido de tu sistema. Conecta un micrófono e inténtalo de nuevo)."
            elif "pyaudio" in err.lower() or "could not import" in err.lower():
                detail = "\n(Falta instalar o configurar correctamente la librería PyAudio)."
            else:
                detail = f"\nDetalle técnico: {err}"
            self.append_chat("SISTEMA", f"Micrófono no disponible.{detail}")
            return

        def run_listening():
            self.is_listening = True
            
            # Callback para cambiar estado de UI durante escucha
            def update_status(msg):
                self.hud_status = msg.upper()
                if "ESCUCHANDO" in self.hud_status or "RUIDO" in self.hud_status or "PROCESANDO" in self.hud_status:
                    self.is_listening = True
                else:
                    self.is_listening = False

            query = self.voice_engine.listen(update_status)
            self.is_listening = False
            
            if query:
                self.hud_status = "PROCESANDO"
                self.commands_count += 1
                self.append_chat("USUARIO", f"[Voz] {query}")
                
                self.is_speaking = True
                self.hud_status = "HABLANDO"
                
                response = self.chatbot.process_input(query, self)
                self.append_chat("JARVIS", response)
                self.voice_engine.speak(response)
                
                time.sleep(max(len(response) * 0.08, 2))
                self.is_speaking = False
                self.hud_status = "STANDBY"
            else:
                # Mostrar en el chat el estado de por qué falló
                self.append_chat("SISTEMA", f"No se pudo transcribir voz. Estado final: {self.hud_status}")
                # Esperar 3 segundos con el estado de error antes de regresar a standby
                self.root.after(3000, self.reset_to_standby)

        threading.Thread(target=run_listening, daemon=True).start()

    def reset_to_standby(self):
        if not self.is_listening and not self.is_speaking:
            self.hud_status = "STANDBY"

    def toggle_ai_mode(self):
        """Alterna entre modo de Comandos Locales e Inteligencia Artificial."""
        if self.ai_mode_active:
            self.ai_mode_active = False
            self.mode_btn.config(text="🤖 LOCAL", fg=COLOR_GREEN)
            self.entry_field.config(highlightcolor=COLOR_CYAN, highlightbackground="#1E293B")
        else:
            self.ai_mode_active = True
            self.mode_btn.config(text="⚡ GEMINI", fg=COLOR_CYAN)
            self.entry_field.config(highlightcolor=COLOR_CYAN, highlightbackground=COLOR_CYAN)

    def toggle_camera(self):
        """Controlador para activar y refrescar la webcam usando OpenCV."""
        if self.camera_active:
            self.camera_active = False
            self.camera_label.config(text="Camera Off\n(Click to turn on / switch)", image="")
            if self.cap:
                self.cap.release()
                self.cap = None
        else:
            # Intentar abrir la webcam usando el índice seleccionado
            self.cap = cv2.VideoCapture(self.camera_index)
            if self.cap.isOpened():
                self.camera_active = True
                self.camera_label.config(text="")
                self.update_camera_frame()
            else:
                self.camera_label.config(text=f"Failed to open Camera\nIndex {self.camera_index}")
                self.cap = None

    def on_camera_click(self, event=None):
        """Si la cámara está encendida, cicla al siguiente índice para cambiar de webcam (0, 1, 2, 3)."""
        if self.camera_active:
            self.camera_index = (self.camera_index + 1) % 4
            self.append_chat("SISTEMA", f"Cambiando a dispositivo de video: Cámara {self.camera_index}")
            if self.cap:
                self.cap.release()
            self.cap = cv2.VideoCapture(self.camera_index)
            if not self.cap.isOpened():
                self.camera_label.config(text=f"Failed to open Camera\nIndex {self.camera_index}", image="")
                self.cap = None
        else:
            self.toggle_camera()

    def update_camera_frame(self):
        """Hilo seguro en Tkinter para actualizar los frames de la cámara y procesar gestos."""
        if self.camera_active and self.cap:
            ret, frame = self.cap.read()
            if ret:
                import numpy as np
                # Espejar la imagen para naturalidad
                frame = cv2.flip(frame, 1)
                h, w, _ = frame.shape
                
                # Definir Región de Interés (ROI) donde el usuario coloca la mano
                x1, y1 = int(w * 0.55), int(h * 0.2)
                x2, y2 = int(w * 0.95), int(h * 0.8)
                
                # Dibujar rectángulo guía del sensor gestual
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 240, 255), 2)
                cv2.putText(frame, "SENSOR DE GESTOS", (x1, y1 - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 240, 255), 1)
                
                # Extraer ROI para procesar
                roi = frame[y1:y2, x1:x2]
                fingers = 0
                
                try:
                    # Convertir a HSV y filtrar color de piel
                    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
                    lower_skin = np.array([0, 20, 70], dtype=np.uint8)
                    upper_skin = np.array([20, 255, 255], dtype=np.uint8)
                    mask = cv2.inRange(hsv, lower_skin, upper_skin)
                    
                    # Suavizar máscara
                    mask = cv2.GaussianBlur(mask, (5, 5), 0)
                    _, thresh = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
                    
                    # Encontrar contornos
                    contours, _ = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                    
                    if contours:
                        # Tomar el contorno más grande (que asumimos es la mano)
                        contour = max(contours, key=lambda x: cv2.contourArea(x))
                        
                        if cv2.contourArea(contour) > 2500:
                            # Calcular envolvente convexa y defectos de convexidad
                            hull = cv2.convexHull(contour, returnPoints=False)
                            defects = cv2.convexityDefects(contour, hull)
                            
                            count_defects = 0
                            if defects is not None:
                                for i in range(defects.shape[0]):
                                    s, e, f, d = defects[i, 0]
                                    start = tuple(contour[s][0])
                                    end = tuple(contour[e][0])
                                    far = tuple(contour[f][0])
                                    
                                    # Distancias de los lados del triángulo
                                    a = math.sqrt((end[0] - start[0])**2 + (end[1] - start[1])**2)
                                    b = math.sqrt((far[0] - start[0])**2 + (far[1] - start[1])**2)
                                    c = math.sqrt((end[0] - far[0])**2 + (end[1] - far[1])**2)
                                    
                                    # Ángulo para identificar los espacios entre dedos
                                    angle = math.acos((b**2 + c**2 - a**2) / (2 * b * c)) * 57.295
                                    
                                    # Si el ángulo es menor a 90 grados, cuenta como espacio interdigital
                                    if angle <= 90 and d > 3000:
                                        count_defects += 1
                                        cv2.circle(roi, far, 4, (0, 0, 255), -1)
                                
                                fingers = count_defects + 1 if count_defects > 0 else 1
                            else:
                                fingers = 1
                            
                            # Mostrar el conteo en el recuadro
                            cv2.putText(frame, f"Dedos: {fingers}", (x1, y2 + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                            
                            # Validar estabilidad del gesto para evitar falsos positivos
                            if fingers == self.last_finger_count:
                                self.finger_counter_frames += 1
                            else:
                                self.last_finger_count = fingers
                                self.finger_counter_frames = 0
                                
                            if self.finger_counter_frames >= 15: # Estable por 15 frames (~500ms)
                                self.trigger_finger_command(fingers)
                                self.finger_counter_frames = 0
                        else:
                            self.finger_counter_frames = 0
                    else:
                        self.finger_counter_frames = 0
                except Exception as ex:
                    pass
                
                # Redimensionar al espacio de la tarjeta GUI
                frame = cv2.resize(frame, (270, 140))
                
                # Convertir color de BGR a RGB
                cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
                img = Image.fromarray(cv2image)
                imgtk = ImageTk.PhotoImage(image=img)
                self.camera_label.imgtk = imgtk
                self.camera_label.config(image=imgtk)
            self.root.after(33, self.update_camera_frame)

    def trigger_finger_command(self, count):
        """Ejecuta un comando en base al número de dedos detectados de forma estable."""
        now = time.time()
        # Cooldown de 2.5 segundos para evitar ejecuciones repetidas continuas accidentalmente
        if now - self.last_triggered_time < 2.5:
            return
            
        self.last_triggered_time = now
        self.last_triggered_count = count
        
        if count == 1:
            self.append_chat("SISTEMA", "[Gesto Detectado] 1 Dedo ➔ Abriendo YouTube...")
            def run():
                self.chatbot.process_input("/youtube", self)
            threading.Thread(target=run, daemon=True).start()
        elif count == 2:
            self.append_chat("SISTEMA", "[Gesto Detectado] 2 Dedos ➔ Abriendo Calculadora...")
            def run():
                self.chatbot.process_input("/calculator", self)
            threading.Thread(target=run, daemon=True).start()
        elif count == 3:
            self.append_chat("SISTEMA", "[Gesto Detectado] 3 Dedos ➔ Abriendo Bloc de Notas...")
            def run():
                self.chatbot.process_input("/notepad", self)
            threading.Thread(target=run, daemon=True).start()
        elif count == 4:
            self.append_chat("SISTEMA", "[Gesto Detectado] 4 Dedos ➔ Activando Escucha por Voz...")
            self.root.after(0, self.listen_voice_message)
        elif count == 5:
            self.append_chat("SISTEMA", "[Gesto Detectado] 5 Dedos ➔ Limpiando Chat...")
            self.root.after(0, self.clear_chat)

    def clear_chat(self):
        self.chat_history.configure(state='normal')
        self.chat_history.delete(1.0, tk.END)
        self.chat_history.configure(state='disabled')
        # Limpiar también el historial de conversación en el plugin de Gemini
        from commands import GeminiSearchCommand
        for cmd in self.chatbot.registry.commands:
            if isinstance(cmd, GeminiSearchCommand):
                cmd.history = []

    def shutdown(self):
        self.append_chat("JARVIS", "Desconectando servidores centrales. Apagando sistemas...")
        self.is_speaking = True
        self.voice_engine.speak("Desconectando servidores. Adiós.")
        # Liberar la cámara antes de cerrar
        if self.cap:
            self.cap.release()
        self.root.after(1500, self.root.destroy)


def show_splash_screen(on_complete_callback):
    """Crea una ventana de bienvenida sin bordes simulando la inicialización del sistema Jarvis."""
    splash = tk.Tk()
    splash.title("Inicializando J.A.R.V.I.S")
    
    width = 500
    height = 350
    
    screen_width = splash.winfo_screenwidth()
    screen_height = splash.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2
    splash.geometry(f"{width}x{height}+{x}+{y}")
    
    splash.overrideredirect(True)
    splash.configure(bg=COLOR_BG)

    frame = tk.Frame(splash, bg=COLOR_BG, bd=2, relief=tk.RIDGE, highlightbackground=COLOR_CYAN, highlightcolor=COLOR_CYAN, highlightthickness=1)
    frame.pack(fill=tk.BOTH, expand=True)

    title = tk.Label(frame, text="⚡ J.A.R.V.I.S SYSTEM", font=("Courier New", 26, "bold"), fg=COLOR_CYAN, bg=COLOR_BG)
    title.pack(pady=(40, 10))

    subtitle = tk.Label(frame, text="PROTOCOLO DE SEGURIDAD UNIVERSITARIO", font=("Courier New", 10, "bold"), fg=COLOR_BLUE, bg=COLOR_BG)
    subtitle.pack()

    log_text = tk.Label(frame, text="Inicializando módulos del sistema...", font=("Consolas", 8), fg=COLOR_DARK_TEXT, bg=COLOR_BG)
    log_text.pack(pady=(30, 5))

    # Barra de progreso
    progress_bar_bg = tk.Frame(frame, width=350, height=8, bg=COLOR_CARD)
    progress_bar_bg.pack(pady=10)
    progress_bar_bg.pack_propagate(False)

    progress_bar = tk.Frame(progress_bar_bg, width=0, height=8, bg=COLOR_CYAN)
    progress_bar.pack(side=tk.LEFT)

    modules = [
        "Conectando al puerto de entrada de voz...",
        "Inicializando biblioteca PyTTSX3 (Text-to-Speech)...",
        "Configurando SpeechRecognition para idioma Español...",
        "Instanciando matriz de comandos (Sistema de Plugins)...",
        "Cargando registros de logs históricos...",
        "Estableciendo canal GUI seguro con Tkinter...",
        "Acceso Concedido. Bienvenido Stark."
    ]
    
    step_val = 350 / len(modules)

    def update_step(index):
        if index < len(modules):
            log_text.config(text=modules[index])
            progress_bar.config(width=int(step_val * (index + 1)))
            splash.after(400, lambda: update_step(index + 1))
        else:
            splash.destroy()
            on_complete_callback()

    splash.after(100, lambda: update_step(0))
    splash.mainloop()
