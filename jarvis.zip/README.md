# Jarvis Python Assistant

Este proyecto es un asistente virtual modular de escritorio diseñado en **Python 3.12+**. Su principal objetivo es demostrar capacidades clave en Python tales como: reconocimiento de voz en tiempo real, síntesis de voz, automatización del sistema operativo y diseño de interfaces de usuario modernas utilizando **Tkinter**.

---

## 🛠️ Estructura del Proyecto

El proyecto está diseñado bajo principios de programación orientada a objetos (POO) y modularidad:

```text
jarvis/
│
├── main.py            # Punto de entrada de la aplicación. Gestiona la pantalla de carga y la ventana principal.
├── gui.py             # Define la interfaz gráfica, el tema oscuro premium y el reactor Arc animado.
├── voice.py           # Motores TTS (pyttsx3) y STT (SpeechRecognition) con manejo de errores/fallbacks.
├── commands.py        # Registro de comandos y sistema de plugins. Facilita la adición de nuevas acciones.
├── chatbot.py         # Procesador de lenguaje e intenciones locales (QA por regex y ruteo a comandos).
├── utils.py           # Funciones de utilidad (fechas, cálculo matemático y registro en archivo de texto).
│
├── conversation_log.txt  # Historial acumulado de conversaciones del asistente (Generado automáticamente).
└── requirements.txt   # Dependencias de Python requeridas para el funcionamiento.
```

---

## 💻 Requisitos e Instalación

### 1. Clonar o descargar el proyecto
Asegúrate de tener todos los archivos en un mismo directorio (ej. `/jarvis`).

### 2. Crear un entorno virtual (Recomendado)
Abre tu consola en la carpeta raíz del proyecto y ejecuta:
```bash
python -m venv venv
```

Para activarlo:
- **En Windows (PowerShell):**
  ```powershell
  .\venv\Scripts\Activate.ps1
  ```
- **En Windows (CMD):**
  ```cmd
  .\venv\Scripts\activate.bat
  ```
- **En Linux / macOS:**
  ```bash
  source venv/bin/activate
  ```

### 3. Instalar Dependencias
Instala las librerías necesarias con el siguiente comando:
```bash
pip install -r requirements.txt
```

> [!IMPORTANT]
> **Nota para PyAudio (Requerido por SpeechRecognition):**
> Si encuentras problemas para instalar `pyaudio` en Windows mediante `pip install -r requirements.txt`, puedes instalarlo ejecutando:
> ```bash
> pip install pipwin
> pipwin install pyaudio
> ```
> O descargar la rueda (`wheel`) correspondiente a tu versión de Python y arquitectura desde repositorios oficiales de binarios de Python no oficiales e instalarla directamente con `pip install archivo.whl`.

---

## 🚀 Cómo Ejecutar el Proyecto

Una vez que las dependencias estén instaladas y el entorno virtual esté activo, simplemente ejecuta:

```bash
python main.py
```

### ¿Qué sucederá al iniciar?
1. **Pantalla de Carga (Splash Screen):** Se mostrará una ventana negra HUD con el logo "JARVIS SYSTEM", simulando de forma animada la inicialización secuencial de todos los periféricos y componentes de inteligencia artificial.
2. **Interfaz Principal:** Posteriormente, emergerá el panel de control oscuro con un **Reactor Arc** animado en constante rotación.
3. **Conversación:** Podrás escribir comandos en el cuadro de texto y pulsar "Enter" o hacer clic en "Enviar". También podrás hacer clic en "Escuchar" para dictarle instrucciones verbales.

---

## 🔧 Ampliando Funcionalidades (Sistema de Plugins)

Puedes agregar comandos personalizados de manera muy fácil en [commands.py](file:///D:/VIII%20ciclo%20sistemas/develope/jarvis/commands.py):

1. Define tu clase heredando de `BaseCommand`:
   ```python
   class MiNuevoComando(BaseCommand):
       @property
       def keywords(self):
           return ["palabra clave 1", "palabra clave 2"]

       @property
       def description(self):
           return "Descripción corta de qué hace."

       def execute(self, text_input, app_instance=None):
           # Lógica en Python
           return "Ejecutando acción con éxito."
   ```
2. Registra tu comando en la función `load_default_commands`:
   ```python
   def load_default_commands(registry: CommandRegistry):
       ...
       registry.register(MiNuevoComando())
   ```
