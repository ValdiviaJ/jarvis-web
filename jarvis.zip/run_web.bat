@echo off
echo Iniciando servidor local para la aplicacion web de J.A.R.V.I.S...
echo Abre tu navegador en: http://localhost:8000
python -m http.server 8000 --directory web
pause
