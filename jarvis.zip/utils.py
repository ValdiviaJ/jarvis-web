import datetime
import os
import re

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "conversation_log.txt")

def log_conversation(sender: str, message: str):
    """
    Guarda el historial de la conversación en un archivo de texto con fecha y hora.
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{timestamp}] {sender}: {message}\n"
    try:
        # Asegurarse de que el directorio del log exista
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(log_line)
    except Exception as e:
        print(f"Error al escribir en el registro de conversación: {e}")

def get_current_time() -> str:
    """
    Retorna la hora actual formateada en español.
    """
    now = datetime.datetime.now()
    return f"Son las {now.strftime('%I:%M %p')}"

def get_current_date() -> str:
    """
    Retorna la fecha actual detallada en español.
    """
    now = datetime.datetime.now()
    dias = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
    meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
    
    dia_semana = dias[now.weekday()]
    dia = now.day
    mes = meses[now.month - 1]
    year = now.year
    
    return f"Hoy es {dia_semana}, {dia} de {mes} del año {year}."

def calculate_expression(expression: str) -> str:
    """
    Evalúa una expresión matemática simple de manera segura usando expresiones regulares.
    """
    # Limpiar entrada: remover letras excepto operadores y números
    clean_expr = re.sub(r'[^0-9+\-*/().\s]', '', expression)
    try:
        if not clean_expr.strip():
            return "No entendí la operación matemática."
        # Evaluar la expresión matemática
        result = eval(clean_expr, {"__builtins__": None}, {})
        return f"El resultado de {expression.strip()} es {result}."
    except Exception:
        return "Lo siento, no pude resolver ese cálculo matemático."
