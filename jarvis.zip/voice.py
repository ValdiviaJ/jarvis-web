import threading
import speech_recognition as sr
import pyttsx3

class VoiceEngine:
    def __init__(self):
        self.tts_enabled = True
        self.stt_enabled = True
        
        # Inicializar motor TTS (Text to Speech)
        try:
            self.engine = pyttsx3.init()
            # Ajustar velocidad y volumen
            self.engine.setProperty('rate', 160)
            self.engine.setProperty('volume', 0.9)
            
            # Configurar voz en español si está disponible
            voices = self.engine.getProperty('voices')
            spanish_voice_found = False
            for voice in voices:
                if "spanish" in voice.name.lower() or "es" in voice.languages or "spa" in voice.id.lower():
                    self.engine.setProperty('voice', voice.id)
                    spanish_voice_found = True
                    break
            
            # Si no encuentra explícitamente español, intentar con la primera por defecto
            if not spanish_voice_found and voices:
                self.engine.setProperty('voice', voices[0].id)
        except Exception as e:
            print(f"[Advertencia] No se pudo inicializar pyttsx3: {e}. El asistente funcionará solo en modo texto.")
            self.tts_enabled = False
            
        self.stt_error = ""
        # Inicializar el reconocedor de voz (Speech to Text) de forma segura
        try:
            self.recognizer = sr.Recognizer()
            
            # Verificar de forma limpia la disponibilidad del micrófono con pyaudio
            import pyaudio
            p = pyaudio.PyAudio()
            try:
                device_count = p.get_device_count()
                has_input_device = False
                for i in range(device_count):
                    device_info = p.get_device_info_by_index(i)
                    if device_info.get("maxInputChannels", 0) > 0:
                        has_input_device = True
                        break
                if not has_input_device:
                    raise Exception("No default input device found (No se detectó ningún micrófono)")
            finally:
                p.terminate()
        except Exception as e:
            self.stt_error = str(e)
            print(f"[Advertencia] Micrófono no detectado: {e}")
            self.stt_enabled = False

    def speak(self, text: str):
        """
        Pronuncia un texto usando el motor TTS de manera sincrónica.
        """
        if not self.tts_enabled:
            print(f"Jarvis (Sin Audio): {text}")
            return
            
        # Ejecutar en un hilo separado o bloquear ordenadamente
        def run_speak():
            try:
                self.engine.say(text)
                self.engine.runAndWait()
            except Exception as e:
                print(f"Error en reproducción de voz: {e}")

        # Ejecutamos en un hilo para no congelar la GUI principal
        threading.Thread(target=run_speak, daemon=True).start()

    def listen(self, callback_status) -> str:
        """
        Escucha a través del micrófono instanciado localmente (evita colisiones de contexto)
        y retorna el texto reconocido.
        """
        if not self.stt_enabled:
            callback_status("Micrófono no disponible")
            return ""

        try:
            # Instanciar el micrófono de manera local y limpia en cada escucha
            microphone = sr.Microphone()
            with microphone as source:
                callback_status("Ajustando ruido...")
                # Calibración rápida de ruido ambiente
                self.recognizer.adjust_for_ambient_noise(source, duration=0.6)
                callback_status("Escuchando...")
                audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=8)
                
            callback_status("Procesando voz...")
            query = self.recognizer.recognize_google(audio, language="es-ES")
            callback_status("Listo")
            return query
        except sr.WaitTimeoutError:
            callback_status("Tiempo de espera agotado")
            return ""
        except sr.UnknownValueError:
            callback_status("No se entendió el audio")
            return ""
        except sr.RequestError as e:
            callback_status("Error de conexión API Google")
            print(f"Error de conexión con Google STT API: {e}")
            return ""
        except Exception as e:
            callback_status("Error al escuchar")
            print(f"Error en proceso de escucha: {e}")
            return ""
