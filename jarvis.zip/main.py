import os
import tkinter as tk
from tkinter import messagebox
from dotenv import load_dotenv
from gui import JarvisApp, show_splash_screen

# Cargar variables de entorno del archivo .env
load_dotenv()

def verificar_api_key():
    """
    Verifica si existe la API Key de Gemini en las variables de entorno.
    Si no existe o tiene el valor por defecto, abre un asistente gráfico en Tkinter.
    """
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    api_key = os.getenv("GEMINI_API_KEY")
    
    if api_key and api_key.strip() != "tu_api_key_de_gemini_aqui" and len(api_key.strip()) > 10:
        return True
        
    setup_win = tk.Tk()
    setup_win.title("J.A.R.V.I.S. - Configuración")
    setup_win.geometry("460x280")
    setup_win.configure(bg="#030712")
    setup_win.resizable(False, False)
    
    # Centrar ventana
    sw = setup_win.winfo_screenwidth()
    sh = setup_win.winfo_screenheight()
    x = (sw - 460) // 2
    y = (sh - 280) // 2
    setup_win.geometry(f"+{x}+{y}")
    
    # Borde cian futurista
    frame = tk.Frame(setup_win, bg="#030712", bd=2, relief=tk.RIDGE, highlightbackground="#00F0FF", highlightcolor="#00F0FF", highlightthickness=1)
    frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(
        frame, 
        text="⚡ CONFIGURACIÓN DE J.A.R.V.I.S", 
        font=("Courier New", 14, "bold"), 
        fg="#00F0FF", bg="#030712"
    ).pack(pady=(25, 10))
    
    tk.Label(
        frame, 
        text="Para activar las funciones de Inteligencia Artificial (Gemini),\ningresa tu API Key. Si no tienes una, obtenla gratis en el botón de abajo.", 
        font=("Segoe UI", 9), fg="#64748B", bg="#030712", justify=tk.CENTER
    ).pack(pady=5)
    
    key_entry = tk.Entry(
        frame, 
        font=("Consolas", 10), 
        width=48, 
        bd=0, 
        highlightthickness=1, 
        highlightbackground="#1E293B", 
        highlightcolor="#00F0FF", 
        bg="#0B1329", 
        fg="#E2E8F0", 
        insertbackground="#00F0FF"
    )
    key_entry.pack(pady=15, ipady=4)
    key_entry.focus_set()
    
    def guardar_key():
        key = key_entry.get().strip()
        if not key:
            messagebox.showwarning("Advertencia", "La API Key no puede estar vacía. Si deseas continuar sin IA, escribe 'OMITIR'.")
            return
            
        try:
            with open(env_path, "w", encoding="utf-8") as f:
                f.write(f"GEMINI_API_KEY={key}\n")
            
            # Forzar actualización en el proceso actual
            os.environ["GEMINI_API_KEY"] = key
            setup_win.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el archivo .env: {e}")
            
    btn_frame = tk.Frame(frame, bg="#030712")
    btn_frame.pack(pady=10)
    
    tk.Button(
        btn_frame, 
        text="Guardar y Continuar", 
        font=("Segoe UI", 9, "bold"), 
        bg="#0072FF", 
        fg="#FFFFFF", 
        bd=0, 
        padx=15, 
        pady=6, 
        cursor="hand2",
        command=guardar_key
    ).pack(side=tk.LEFT, padx=10)
    
    def abrir_link():
        import webbrowser
        webbrowser.open("https://aistudio.google.com/")
        
    tk.Button(
        btn_frame, 
        text="Obtener Key Gratis 🌐", 
        font=("Segoe UI", 9, "bold"), 
        bg="#0B1329", 
        fg="#00F0FF", 
        bd=1, 
        highlightbackground="#1E293B",
        highlightthickness=1,
        padx=15, 
        pady=5, 
        cursor="hand2",
        command=abrir_link
    ).pack(side=tk.LEFT, padx=10)
    
    setup_win.mainloop()

def main():
    """
    Función de entrada principal para el Jarvis Python Assistant.
    Primero inicializa la pantalla de carga (Splash Screen)
    y luego abre la ventana de interfaz de control principal.
    """
    # Verificar configuración inicial
    verificar_api_key()
    
    # Callback que se ejecuta cuando el Splash Screen se cierra
    def launch_main_app():
        root = tk.Tk()
        # Inicializar la aplicación Jarvis
        app = JarvisApp(root)
        
        # Iniciar el bucle de eventos principal de Tkinter
        root.mainloop()

    # Lanzar pantalla de bienvenida
    show_splash_screen(launch_main_app)

if __name__ == "__main__":
    main()

