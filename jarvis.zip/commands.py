import os
import subprocess
import webbrowser
import sys
from abc import ABC, abstractmethod
from typing import List, Callable

class BaseCommand(ABC):
    """
    Clase base para todos los comandos (Plugins).
    Para crear un nuevo comando, hereda de esta clase e impleméntala.
    """
    @property
    @abstractmethod
    def keywords(self) -> List[str]:
        """Palabras clave asociadas a este comando."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Descripción del comando."""
        pass

    @abstractmethod
    def execute(self, text_input: str, app_instance=None) -> str:
        """Ejecución lógica del comando. Retorna la respuesta en formato de texto."""
        pass


class CommandRegistry:
    """
    Registro centralizado para todos los comandos / plugins del asistente.
    """
    def __init__(self):
        self.commands: List[BaseCommand] = []

    def register(self, command: BaseCommand):
        self.commands.append(command)

    def find_command(self, text: str) -> BaseCommand:
        """
        Busca un comando que coincida con el texto provisto.
        Prioriza la coincidencia exacta de comandos de barra (ej. /search).
        """
        text_lower = text.strip().lower()
        if text_lower.startswith("/"):
            # Dividir para obtener la primera palabra (el comando barra)
            parts = text_lower.split()
            if parts:
                first_word = parts[0]
                for cmd in self.commands:
                    if any(kw.lower() == first_word for kw in cmd.keywords if kw.startswith("/")):
                        return cmd
        
        # Búsqueda tradicional de palabras clave
        for cmd in self.commands:
            for keyword in cmd.keywords:
                if keyword in text_lower:
                    return cmd
        return None


# ========================================================
# IMPLEMENTACIÓN DE COMANDOS POR DEFECTO (PLUGINS)
# ========================================================

class OpenNotepadCommand(BaseCommand):
    @property
    def keywords(self) -> List[str]:
        return ["abrir bloc de notas", "abrir notas", "abre el bloc de notas", "ejecutar bloc de notas", "abre bloc de notas", "abrir notepad", "abre notepad", "notepad", "bloc de notas", "/notepad"]

    @property
    def description(self) -> str:
        return "Abre el editor de texto Bloc de notas de Windows."

    def execute(self, text_input: str, app_instance=None) -> str:
        try:
            subprocess.Popen("notepad.exe")
            return "Abriendo el Bloc de notas."
        except Exception as e:
            return f"No se pudo abrir el Bloc de notas. Error: {e}"


class OpenCalculatorCommand(BaseCommand):
    @property
    def keywords(self) -> List[str]:
        return ["abrir calculadora", "abre la calculadora", "ejecutar calculadora", "abre calculadora", "abrir la calculadora", "calculadora", "ejecuta calculadora", "/calculator"]

    @property
    def description(self) -> str:
        return "Abre la calculadora del sistema."

    def execute(self, text_input: str, app_instance=None) -> str:
        try:
            if sys.platform == "win32":
                subprocess.Popen("calc.exe")
            else:
                # Intento genérico para Linux/Mac
                subprocess.Popen("bc")
            return "Abriendo la calculadora."
        except Exception as e:
            return f"No se pudo abrir la calculadora. Error: {e}"


class OpenBrowserCommand(BaseCommand):
    @property
    def keywords(self) -> List[str]:
        return ["abrir navegador", "abre el navegador", "abrir internet"]

    @property
    def description(self) -> str:
        return "Abre el navegador web por defecto del sistema."

    def execute(self, text_input: str, app_instance=None) -> str:
        try:
            webbrowser.open("https://www.google.com")
            return "Abriendo el navegador web."
        except Exception as e:
            return f"No se pudo abrir el navegador. Error: {e}"


class OpenGoogleCommand(BaseCommand):
    @property
    def keywords(self) -> List[str]:
        return ["abrir google", "abre google", "buscar en google", "google", "busca en google", "/google"]

    @property
    def description(self) -> str:
        return "Abre Google en el navegador web."

    def execute(self, text_input: str, app_instance=None) -> str:
        try:
            # Si contiene "buscar en google" seguido de algo, hacemos una búsqueda directa
            search_prefix = "buscar en google"
            text_lower = text_input.lower()
            if search_prefix in text_lower:
                query = text_input[text_lower.find(search_prefix) + len(search_prefix):].strip()
                if query:
                    webbrowser.open(f"https://www.google.com/search?q={query}")
                    return f"Buscando '{query}' en Google."
            webbrowser.open("https://www.google.com")
            return "Abriendo Google en el navegador."
        except Exception as e:
            return f"No se pudo abrir Google. Error: {e}"


class OpenYoutubeCommand(BaseCommand):
    @property
    def keywords(self) -> List[str]:
        return ["abrir youtube", "abre youtube", "ver youtube", "youtube", "reproducir youtube", "/youtube"]

    @property
    def description(self) -> str:
        return "Abre la plataforma de videos YouTube."

    def execute(self, text_input: str, app_instance=None) -> str:
        try:
            webbrowser.open("https://www.youtube.com")
            return "Abriendo YouTube en tu navegador."
        except Exception as e:
            return f"No se pudo abrir YouTube. Error: {e}"


class CloseAppCommand(BaseCommand):
    @property
    def keywords(self) -> List[str]:
        return ["cerrar aplicación", "apágate", "apagar", "salir", "terminar", "cerrar programa", "adiós jarvis", "/exit"]

    @property
    def description(self) -> str:
        return "Cierra el asistente de forma segura."

    def execute(self, text_input: str, app_instance=None) -> str:
        if app_instance and hasattr(app_instance, "shutdown"):
            # Programar cierre en la app
            app_instance.shutdown()
        else:
            sys.exit(0)
        return "Cerrando el asistente. ¡Hasta luego!"


class WikipediaSearchCommand(BaseCommand):
    @property
    def keywords(self) -> List[str]:
        return ["buscar en wikipedia", "busca en wikipedia", "wikipedia", "quién es", "qué es", "quién fue", "busca sobre"]

    @property
    def description(self) -> str:
        return "Busca un concepto en Wikipedia en español y resume el resultado."

    def execute(self, text_input: str, app_instance=None) -> str:
        # Importar dinámicamente requests para este plugin
        import requests
        
        query = text_input.lower()
        # Eliminar las palabras clave de la consulta
        for kw in self.keywords:
            if kw in query:
                query = query.replace(kw, "", 1)
        
        # Limpiar conectores gramaticales al inicio
        query = query.strip()
        for connector in ["de", "la", "el", "sobre", "un", "una"]:
            if query.startswith(connector + " "):
                query = query[len(connector) + 1:].strip()
                break
                
        if not query:
            return "Por favor especifica qué deseas buscar en Wikipedia."

        try:
            # Deshabilitar advertencias de SSL no verificado (común en PCs de centros de estudio)
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

            url = "https://es.wikipedia.org/w/api.php"
            params = {
                "action": "query",
                "format": "json",
                "prop": "extracts",
                "exintro": True,
                "explaintext": True,
                "titles": query,
                "redirects": 1
            }
            headers = {
                "User-Agent": "JarvisAssistantUniversityProject/1.0 (contact@university.edu)"
            }
            # Hacer petición con User-Agent y omitiendo verificación SSL para mayor compatibilidad
            response = requests.get(url, params=params, headers=headers, timeout=10, verify=False)
            if response.status_code == 200:
                data = response.json()
                pages = data.get("query", {}).get("pages", {})
                page_id = next(iter(pages))
                
                if page_id == "-1":
                    return f"Lo siento, no pude encontrar información sobre '{query}' en Wikipedia."
                
                page_data = pages[page_id]
                title = page_data.get("title", "")
                extract = page_data.get("extract", "")
                
                if not extract.strip():
                    return f"Encontré la página de '{title}' en Wikipedia, pero no tiene un resumen disponible."
                
                # Tomar solo las primeras dos oraciones para la lectura por voz
                sentences = extract.split(". ")
                summary = ". ".join(sentences[:2])
                if not summary.endswith("."):
                    summary += "."
                    
                return f"Según Wikipedia: {summary}"
            else:
                return f"No pude conectar con los servidores de Wikipedia (Código de estado HTTP: {response.status_code})."
        except Exception as e:
            return f"No pude conectar con los servidores de Wikipedia. Error: {e}"


class GeminiSearchCommand(BaseCommand):
    def __init__(self):
        # Almacena el historial de conversación en el formato requerido por la API
        self.history = []

    @property
    def keywords(self) -> List[str]:
        return ["/search", "/gemini", "preguntar a la ia", "consulta a la ia"]

    @property
    def description(self) -> str:
        return "Realiza consultas al modelo Gemini 1.5 Flash de Google usando tu API key."

    def execute(self, text_input: str, app_instance=None) -> str:
        import requests
        import os
        
        # Obtener la API key y sanitizarla (eliminar espacios y comillas)
        api_key = os.getenv("GEMINI_API_KEY")
        if api_key:
            api_key = api_key.strip().strip('"').strip("'")
            
        if not api_key or api_key == "tu_api_key_de_gemini_aqui":
            return ("Para consultar a Gemini, por favor configura tu API key en el archivo .env\n"
                    "Ejemplo: GEMINI_API_KEY=tu_clave_real. Consíguela gratis en Google AI Studio.")

        # Extraer la consulta
        query = text_input
        for kw in self.keywords:
            if kw in query.lower():
                # Reemplazo insensible a mayúsculas
                idx = query.lower().find(kw)
                query = query[:idx] + query[idx + len(kw):]
        
        query = query.strip()
        if not query:
            return "Por favor ingresa tu pregunta. Ejemplo: /search ¿Por qué el cielo es azul?"

        # Agregar mensaje del usuario al historial
        self.history.append({"role": "user", "parts": [{"text": query}]})
        
        # Mantener solo las últimas 5 interacciones completas (10 mensajes) para controlar tokens y velocidad
        if len(self.history) > 10:
            self.history = self.history[-10:]

        models_to_try = [
            "gemini-2.5-flash",
            "gemini-2.0-flash",
            "gemini-1.5-flash",
            "gemini-pro"
        ]

        last_error = ""
        for model in models_to_try:
            try:
                # Usar endpoint v1beta
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
                headers = {"Content-Type": "application/json"}
                
                # Configurar systemInstruction para forzar la personalidad de Jarvis y brevedad
                payload = {
                    "systemInstruction": {
                        "parts": [{
                            "text": "Eres J.A.R.V.I.S., el asistente virtual interactivo de Tony Stark. Responde de manera servicial, directa, carismática y concisa en español (máximo 3 oraciones por respuesta)."
                        }]
                    },
                    "contents": self.history
                }
                
                response = requests.post(url, json=payload, headers=headers, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    try:
                        text_response = data["candidates"][0]["content"]["parts"][0]["text"]
                        
                        # Guardar la respuesta de la IA en la memoria histórica del chat
                        self.history.append({"role": "model", "parts": [{"text": text_response.strip()}]})
                        return text_response.strip()
                    except (KeyError, IndexError):
                        # En caso de error, remover la última pregunta para no dañar el historial
                        self.history.pop()
                        return "No pude estructurar la respuesta de Gemini de forma correcta."
                elif response.status_code == 404:
                    last_error = f"El modelo {model} no se encuentra habilitado para tu cuenta (HTTP 404)."
                    continue
                else:
                    self.history.pop() # Quitar última pregunta
                    if response.status_code == 429:
                        # Fallback a Wikipedia si se agota la cuota del API de Gemini
                        wiki = WikipediaSearchCommand()
                        wiki_res = wiki.execute(query, app_instance)
                        return f"⚠️ [Cuota de Gemini Agotada - Código 429] Iniciando protocolo de respaldo local:\n\n{wiki_res}"
                    return f"Error en la API de Gemini (Código HTTP: {response.status_code}). Detalle: {response.text[:200]}"
            except Exception as e:
                last_error = f"Error al intentar consultar el modelo {model}: {e}"
                continue
        
        # Si todos los modelos fallaron
        if self.history:
            self.history.pop()
        return f"No se encontró un modelo de Gemini disponible. Último error reportado: {last_error}"


# ========================================================
# INICIALIZACIÓN Y CARGA DE COMANDOS POR DEFECTO
# ========================================================

def load_default_commands(registry: CommandRegistry):
    """
    Carga todos los comandos básicos en el registro.
    Aquí se pueden registrar nuevos plugins.
    """
    registry.register(OpenNotepadCommand())
    registry.register(OpenCalculatorCommand())
    registry.register(OpenBrowserCommand())
    registry.register(OpenGoogleCommand())
    registry.register(OpenYoutubeCommand())
    registry.register(CloseAppCommand())
    registry.register(WikipediaSearchCommand())
    registry.register(GeminiSearchCommand())


